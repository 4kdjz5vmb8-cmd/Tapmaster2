TAPMASTER WEB APP

Files:
- index.html: complete self-contained app. No libraries or build step.

Use on iPhone:
1. The simplest test is to open index.html in a browser preview/editor that supports local HTML.
2. To install it like an app, publish index.html to a static web host, open its HTTPS URL in Safari, tap Share, then Add to Home Screen.
3. This is a web app, not a native IPA. Hosting is needed for reliable Add to Home Screen use.

Features:
- Blue futuristic responsive design
- Tap rate slider and presets (1-20 simulated events/sec)
- Start/stop/reset demo counter
- Accessibility guide
- Explicit warning that it does not tap Roblox or other apps

No external assets, permissions, dependencies, or network calls are required by the app itself.
